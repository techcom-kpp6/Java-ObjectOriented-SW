/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testAccess;
/**
 *
 * @author COM07
 */
public class Main {
    public static void main(String[] args) {
        Hardware Hv = new Hardware("RTX0000", "GPU"); 
        Hv.hvInfo();
        Hv.hvInfo("DDR5", "12GB");
        Hv.hvInfo("2100Mhz", "139Mhz", "83°C");
    }
}
