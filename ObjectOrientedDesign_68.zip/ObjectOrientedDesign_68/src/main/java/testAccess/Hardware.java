/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testAccess;

/**
 *
 * @author COM07
 */
public class Hardware {
    public String Name;
    public String Type;

    public Hardware(String Name, String Type) {
        this.Name = Name;
        this.Type = Type;
    }  
    public void hvInfo(){
        System.out.println("Name: "+Name);
        System.out.println("Software: "+Type);
    }
    public void hvInfo(String MemoryType, String Memory){
        System.out.println("MemoryType: "+MemoryType);
        System.out.println("Memory: "+Memory);
    }
    public void hvInfo(String clock, String idleClock, String tjmax){
        System.out.println("Tjmax: "+tjmax);
        System.out.println("Clock: "+clock);
        System.out.println("IdleClock: "+idleClock);
    }
}
