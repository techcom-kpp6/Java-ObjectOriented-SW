/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interface_test;

/**
 *
 * @author COM07
 */
public class MediaPlayer extends Appliance implements OnOffDevice{
    public void play(){}
    public void pause(){}
    public void skip(){}

    @Override
    public void on() {
        System.out.println("Turn on DVD Player!");
    }

    @Override
    public void off() {
        System.out.println("Turn off DVD Player!");
    }

    @Override
    public void set() {

    }

    @Override
    public void set(int x) {

    }
}
