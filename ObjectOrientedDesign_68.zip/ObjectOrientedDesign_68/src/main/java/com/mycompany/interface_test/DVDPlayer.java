/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interface_test;

/**
 *
 * @author COM07
 */
public class DVDPlayer extends MediaPlayer{
    public void on(){
        
    }
    public void off(){
        
    }
    public void play(){
        
    }
    public void pause(){
        
    }
    public void skip(){
        
    }
}
