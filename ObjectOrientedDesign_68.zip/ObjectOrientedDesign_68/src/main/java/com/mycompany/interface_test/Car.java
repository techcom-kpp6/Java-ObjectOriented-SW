/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interface_test;

/**
 *
 * @author COM07
 */
public abstract class Car {
    //Field
    public String color;
    public int wheels;
    public int doors;
    public int speed;
    //Methods
    public void accelerate(int speed){}
    public void breaks(int x){}
    public String getInformation(){
        return this.color+" "+this.wheels+" "+this.doors;
    }
    public void setColor(String color){
        this.color = color;
    }
    public void setWheels(int wheels){
        this.wheels = wheels;
    }
    public void setDoors(int doors){
        this.doors = doors;
    }
    public void setSpeed(int speed){
        this.speed = speed;
    }
}
