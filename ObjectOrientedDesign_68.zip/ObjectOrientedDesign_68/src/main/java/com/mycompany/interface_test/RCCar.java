/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interface_test;

/**
 *
 * @author COM07
 */
public class RCCar extends Toy implements OnOffDevice{
    @Override
    public void on(){
        System.out.println("Turn on RC Car!");
    }
    @Override
    public void off(){
        System.out.println("Turn off RC Car!");
    }
    @Override
    public void set(){
        
    }
    @Override
    public void set(int x){
        
    }
//    public void brakes(){
//        
//    }
}
