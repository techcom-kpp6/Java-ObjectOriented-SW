/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interface_test;

/**
 *
 * @author COM07
 */
public class Lamp extends Appliance implements OnOffDevice, GetSetDevice{
    public void dim(){
        
    }
    @Override
    public void get(){
        
    }

    @Override
    public void on() {
        System.out.println("Turn on Lamp!");
    }

    @Override
    public void off() {
        System.out.println("Turn off Lamp!");
    }

    @Override
    public void set() {
        
    }

    @Override
    public void set(int x) {
        
    }
}
