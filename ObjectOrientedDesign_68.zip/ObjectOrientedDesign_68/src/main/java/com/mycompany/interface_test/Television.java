/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interface_test;

/**
 *
 * @author COM07
 */
public class Television implements ManageDevice{

    @Override
    public void on() {

    }

    @Override
    public void off() {

    }

    @Override
    public void set() {

    }

    @Override
    public void set(int x) {

    }

    @Override
    public void get() {

    }

    @Override
    public void delete() {

    }
    
}
