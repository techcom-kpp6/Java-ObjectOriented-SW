/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testtread;

/**
 *
 * @author COM07
 */
public class T1 extends Thread{
    public void run(){
        for(int i=0;i<100;i++){
        System.out.println(getName()+":"+i);
            for(int j=0;j<100000000;j++){
                j=j;
            }
        }
    }
}
