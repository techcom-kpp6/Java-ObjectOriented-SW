/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testexception;

/**
 *
 * @author COM07
 */
public class TestException {
    public int getValue(int[] arr, int index) throws Exception{
        int val = 0;
        val = arr[index];
        return val;
    }
    public int convertToNumber(String str) throws Exception{
        return Integer.parseInt(str);
    }
    public void handleException(Exception e){
        e.printStackTrace();
    }
}
