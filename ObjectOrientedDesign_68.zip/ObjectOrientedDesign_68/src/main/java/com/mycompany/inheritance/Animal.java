/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance;

/**
 *
 * @author COM07
 */
public class Animal {
    public String name = "Animal";
    public String type = "Mammal";
    public int legs = 10;
    
    public String sayName(){
        return name;
    }
}
