/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.objectorienteddesign_68;
import com.mycompany.objectorienteddesign_68.Point;
import com.mycompany.objectorienteddesign_68.Car;
import com.mycompany.inheritance.Cat;
import com.mycompany.interface_test.RCCar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author COM07
 */
public class ObjectOrientedDesign_68 {
    public static void main(String[] args) {
        //None Primitive Data
//        Integer x = new Integer(1);
//        System.out.println(x);
//        List list = new ArrayList();
//        list.add("Hello");
//        System.out.println(list);
//        list.add(1, "World2");
//        System.out.println(list);
//        list.add("1");
//        System.out.println(list);
//        
//        Cat c = new Cat();
//        list.add(c.type);
//        System.out.println(list);
//        list.removeFirst();
//        System.out.println(list);
//        list.removeLast();
//        System.out.println(list);
//        list.remove("Hello");
//        System.out.println(list);

//        for(int i=0; i<=list.size()-1;i++){
//            System.out.println(list.get(i));
//        }
//        Iterator<String> iter = list.iterator();
//        while(iter.hasNext()){
//            System.out.println(iter.next());
//        }




//        Set s = new TreeSet();
//        s.add("Hello");
//        System.out.println(s);
//        s.add(list.get(0));
//        System.out.println(s);
//        s.addAll(list);
//        System.out.println(s);
//        s.remove("Hello");
//        System.out.println(s);
//        System.out.println(s.contains("Hello"));
//        s.clear();
//        System.out.println(s);


//HasMap
//    Map<Integer, String> hm = new HashMap<>();
//    hm.put(1, "Hello");
//    hm.put(2, "World");
//    hm.put(3, "F");
//    System.out.println(hm);
//    System.out.println(hm.get(1));
//    System.out.println(hm.size());
//    System.out.println(hm.containsKey(3));
//    System.out.println(hm.containsKey(5));
//    System.out.println(hm.containsValue("F"));
//    
//    
//    System.out.println(hm.isEmpty());
//    hm.clear();
//    System.out.println(hm.size());





//SortedMap sm = new TreeMap();




























//        
//        System.out.println(c.sayName("Dog", 9));
        //        String name = "White";
//        Point p = new Point(10, 10);
//        int x = p.x;
//        int y = p.y;
//        int sum = p.sum(x, y);
//        System.out.println("x = "+x);
//        System.out.println("y= "+y);
//        System.out.println("sum = "+p.sum());
//        System.out.println("sum = "+p.sum(5, 10));
//        p = null;

    }
}






























//------Primitive Data Type------
//Inteeger
//        byte a = 1;
//        short b = 2;
//        int c = 3;
//        long d = 4;
        //Real Number
//        float x = 1.3f;
//        double y = 1.2;
//Character
//        char z = 'A'; //Single Quote
//Boolean
//        boolean boo = true;
//        double d = 1;
//------Primitive Data Type------
//        String s = "Sawet";
//        System.out.println("Hello World1");
//        System.out.println("Hello World2");
//        System.out.println("Hello World3");
//        int n = 10, m = 5;
//        String firstName = "Wat";
//        String lastName = "BB";
//        System.out.println((firstName+ " " + lastName));
//        for(int i=0; i<10; i++){
//            for(int j = 0; j<10; j++){
//                System.out.print('*');
//            }
//            System.out.println('*');
//        }
//        int count = 0;
//        int row = 0;
//        while(count<10){
//            while(row<10){
//                System.out.print('*');
//                row++;
//                if(count==5){break;}
//            }
//            System.out.println('*');
//            count++;
//            row=0;
//        }
//           do{
//               System.out.println('*');
//               column++;
//           }while(column<10);

//        arr = [][]
//        
//        
//        for(int o=0;o<arr.length;o++){
//            for(int i=0;i<arr[0].length;i++){
//                System.out.print(arr[i][o]);
//            }
//        }
        

