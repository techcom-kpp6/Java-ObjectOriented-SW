/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nested;

/**
 *
 * @author COM07
 */
public class A {
    static int aa = 1;
    int a = 2;
    
    static class top {
        static int a = aa;
        int s = a;
    }
//    class member{
//
//    }
//    void inner(){
//        
//    }
}
